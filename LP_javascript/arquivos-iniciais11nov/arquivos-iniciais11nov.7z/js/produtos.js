const produtos = [
					{
						id: 1,
						nome: 'banana',
						preco: 4.99
					},
					{
						id: 2,
						nome: 'abacate',
						preco: 9.99
					},
					{
						id: 3,
						nome: "laranja lima",
						preco: 6.99
					},
					{
						id: 4,
						nome: "laranja pera",
						preco: 2.99
					},
					{
						id: 5,
						nome: "abacaxi",
						preco: 7.99
					},
					{
						id: 6,
						nome: "chuchu",
						preco: 2.99
					},
					{
						id: 7,
						nome: "batata",
						preco: 3.99
					}
				];